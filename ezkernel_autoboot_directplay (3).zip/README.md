# Autoboot Games for EZ-Flash Omega

A custom, streamlined direct-boot OS / kernel for the **EZ-Flash Omega** (standard edition) Game Boy Advance flashcart.

This kernel bypasses the entire user interface (menus, file browsers, splash logos, and loading boxes) to provide an authentic, console-like retail cartridge experience: when you turn on your GBA, it detects the `.gba` ROM on your MicroSD card, loads it into PSRAM, and boots immediately into the game.

To play a different game, simply swap the `.gba` ROM on your MicroSD card.

---

## Key Features

- **Direct Boot to Game**: Automatically scans the root directory of your MicroSD card, identifies the `.gba` ROM (case-insensitive, e.g. `game.gba`, `pokemon_emerald.GBA`), and boots directly into it.
- **Zero UI & Clean Screen Blanking**: Suppresses all boot splash animations and interface drawing routines. The LCD is held in hardware Forced Blank (`REG_DISPCNT = 0x0080`) during the 2–3 second PSRAM loading sequence, providing a clean black screen until the game's title screen appears.
- **Accurate Save Hardware Detection**: Preserves the kernel's internal save database lookup (`Auto_Save_Type`) for clean boot (`r5 = 0`). Correctly configures the FPGA mapping and save allocation for:
  - **128 KB Flash** (*Pokémon Emerald, FireRed, LeafGreen*)
  - **64 KB Flash**
  - **EEPROM (512B / 8KB)**
  - **SRAM**
  Saves are maintained and synchronized cleanly in the standard `/SAVER/` folder (e.g. `/SAVER/<game_name>.sav`).
- **Fail-Safe Fallback**: If no `.gba` file is found on the root of your MicroSD card, the kernel automatically enables the display and falls back to the standard menu interface rather than hanging.

---

## Installation & Setup

### 1. Preparation
1. Back up your existing `ezkernel.bin` and `/SAVER` directory from your MicroSD card to your computer.
2. If an invalid or 0-byte `.sav` file was generated during a previous failed boot, delete it from the `/SAVER/` directory.

### 2. Flashing the Cartridge
1. Copy `ezkernel.bin` to the root directory of your MicroSD card.
2. Place the GBA ROM you want to play (with a `.gba` extension) on the root directory of the card.
3. Insert the card into your EZ-Flash Omega and insert the cart into your GBA / SP / Micro / DS.
4. **Hold the `R` shoulder button**, then turn the console power switch **ON**.
5. Keep holding `R` until the firmware updater screen appears. Let the flashing process complete 100%. **Do not turn off power during the update.**

### 3. Playing & Switching Games
- **Normal Play**: Turn the console on normally (without holding any buttons). Your game will launch directly with zero menus.
- **Switching Games**: Insert your MicroSD card into your computer, delete/move the old `.gba` file, and place the new `.gba` ROM on the root of the card.
- **Reverting to Stock**: Copy the original stock `ezkernel.bin` to the root of the card and boot the GBA while holding the `R` shoulder button.

---

## Building from Source

To patch an official EZ-Flash Omega kernel yourself:

```bash
python3 patch_kernel.py <path_to_stock_ezkernel.bin> ezkernel.bin
```

---

## License

This project is licensed under the Apache License 2.0, matching the original EZ-Flash Omega kernel repository license.
