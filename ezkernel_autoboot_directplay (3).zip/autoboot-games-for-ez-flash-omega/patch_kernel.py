#!/usr/bin/env python3
"""
EZ-Flash Omega Autoboot & Direct-Play Kernel Patcher

This script patches the official EZ-Flash Omega kernel (ezkernel.bin) to create
a streamlined, zero-UI autoboot kernel:
1. Keeps the display blanked (Forced Blank) during boot to eliminate all menus and loading screens.
2. NOPs out the initial splash logo drawing routine.
3. Injects a post-filesystem scan autoboot hook:
   - Scans the root directory file table.
   - Detects the first .gba ROM (case-insensitive).
   - Initializes clean-boot execution parameters.
   - Preserves automatic save type detection (r5 = 0) so the cartridge correctly
     allocates and syncs saves (128KB Flash, 64KB Flash, EEPROM, SRAM) in /SAVER/.
   - Direct-boots into the GBA game.
   - If no .gba file is found, safely turns display on and falls back to stock menu.
"""

import sys
import os
import struct
import hashlib

def make_bl(from_addr, to_addr):
    offset = (to_addr - (from_addr + 4)) & 0xffffffff
    if offset & 0x80000000:
        offset -= 0x100000000
    h1 = 0xf000 | ((offset >> 12) & 0x7ff)
    h2 = 0xf800 | ((offset >> 1) & 0x7ff)
    return struct.pack("<HH", h1, h2)

def make_b_cond(cond, from_addr, to_addr):
    offset = (to_addr - (from_addr + 4)) >> 1
    assert -128 <= offset <= 127, f"b_cond offset {offset} out of range"
    return struct.pack("<H", 0xd000 | (cond << 8) | (offset & 0xff))

def make_b(from_addr, to_addr):
    offset = (to_addr - (from_addr + 4)) >> 1
    assert -1024 <= offset <= 1023, f"b offset {offset} out of range"
    return struct.pack("<H", 0xe000 | (offset & 0x7ff))

def make_ldr_pc(rd, from_addr, target_addr):
    pc_base = (from_addr + 4) & ~3
    offset = target_addr - pc_base
    assert offset >= 0 and offset % 4 == 0 and (offset // 4) <= 255, f"ldr offset {offset} invalid"
    return struct.pack("<H", 0x4800 | (rd << 8) | (offset // 4))

def patch_kernel(input_path, output_path):
    if not os.path.exists(input_path):
        print(f"Error: input file {input_path} not found.")
        sys.exit(1)

    with open(input_path, "rb") as f:
        data = bytearray(f.read())

    print(f"Input file: {input_path} ({len(data)} bytes)")
    print(f"Input SHA256: {hashlib.sha256(data).hexdigest()}")

    # 1. DISPCNT forced blank at boot (0x0080 instead of 0x0403)
    off_dispcnt = 0x00c198
    assert data[off_dispcnt:off_dispcnt+4] == bytes.fromhex("03040000"), "Unexpected DISPCNT value"
    data[off_dispcnt:off_dispcnt+4] = bytes.fromhex("80000000")

    # 2. Skip initial splash screen drawing
    off_splash = 0x00bec6
    assert data[off_splash:off_splash+4] == bytes.fromhex("0bf083fa"), "Unexpected splash call"
    data[off_splash:off_splash+4] = bytes.fromhex("c046c046")

    # 3. Assemble Autoboot Hook at 0x0800bfe2
    lit_file_count = 0x0800c014
    lit_file_list  = 0x0800c018
    lit_clean_boot = 0x0800c01c
    fallback_addr  = 0x0800c020
    found_rom_addr = 0x0800bffe

    instrs = []
    # 0800bfe2: ldr r4, =0x03003f98 (file_count ptr)
    instrs.append(make_ldr_pc(4, 0x0800bfe2, lit_file_count))
    # 0800bfe4: ldr r4, [r4] (read file count)
    instrs.append(struct.pack("<H", 0x6824))
    # 0800bfe6: cmp r4, #0
    instrs.append(struct.pack("<H", 0x2c00))
    # 0800bfe8: beq fallback
    instrs.append(make_b_cond(0, 0x0800bfe8, fallback_addr))
    # 0800bfea: ldr r5, =0x02007cc8 (file list buffer)
    instrs.append(make_ldr_pc(5, 0x0800bfea, lit_file_list))

    # 0800bfec: [search_loop] movs r0, r5
    instrs.append(struct.pack("<H", 0x0028))
    # 0800bfee: bl 0x08003a94 (Check_game)
    instrs.append(make_bl(0x0800bfee, 0x08003a94))
    # 0800bff2: cmp r0, #0
    instrs.append(struct.pack("<H", 0x2800))
    # 0800bff4: beq found_rom (0800bffe)
    instrs.append(make_b_cond(0, 0x0800bff4, found_rom_addr))
    # 0800bff6: adds r5, #0x68
    instrs.append(struct.pack("<H", 0x3568))
    # 0800bff8: subs r4, #1
    instrs.append(struct.pack("<H", 0x3c01))
    # 0800bffa: bne search_loop (0800bfec)
    instrs.append(make_b_cond(1, 0x0800bffa, 0x0800bfec))
    # 0800bffc: b fallback (0800c020)
    instrs.append(make_b(0x0800bffc, fallback_addr))

    # 0800bffe: [found_rom]
    instrs.append(struct.pack("<H", 0x950a)) # str r5, [sp, #0x28] (filename)
    instrs.append(struct.pack("<H", 0x2000)) # movs r0, #0
    instrs.append(struct.pack("<H", 0x9005)) # str r0, [sp, #0x14] (game_type = GBA = 0)
    instrs.append(struct.pack("<H", 0x9009)) # str r0, [sp, #0x24] (menu_choice = CLEAN BOOT = 0)
    instrs.append(struct.pack("<H", 0x900b)) # str r0, [sp, #0x2c] (addon = 0)
    instrs.append(struct.pack("<H", 0x2500)) # movs r5, #0 (CRUCIAL: enables auto save detection)
    instrs.append(struct.pack("<H", 0x2700)) # movs r7, #0 (tab = SD card = 0)
    instrs.append(make_ldr_pc(3, 0x0800c00c, lit_clean_boot))
    instrs.append(struct.pack("<H", 0x4718)) # bx r3
    instrs.append(struct.pack("<H", 0x46c0)) # nop
    instrs.append(struct.pack("<H", 0x46c0)) # nop

    # Literals at 0x0800c014
    instrs.append(struct.pack("<I", 0x03003f98)) # &file_count
    instrs.append(struct.pack("<I", 0x02007cc8)) # &file_list
    instrs.append(struct.pack("<I", 0x0800c9af)) # clean_boot handler

    # Fallback routine at 0x0800c020
    instrs.append(struct.pack("<H", 0x2180)) # movs r1, #0x80
    instrs.append(struct.pack("<H", 0x04c9)) # lsls r1, r1, #19 (REG_DISPCNT)
    lit_0403 = 0x0800c030
    instrs.append(make_ldr_pc(2, 0x0800c024, lit_0403))
    instrs.append(struct.pack("<H", 0x800a)) # strh r2, [r1] (REG_DISPCNT = 0x0403)
    instrs.append(struct.pack("<H", 0x23bb)) # movs r3, #0xbb
    instrs.append(struct.pack("<H", 0x930e)) # str r3, [sp, #56]
    instrs.append(make_b(0x0800c02c, 0x0800c034)) # b 0x0800c034
    instrs.append(struct.pack("<H", 0x46c0)) # nop
    instrs.append(struct.pack("<I", 0x00000403)) # lit_0403

    hook_bytes = b"".join(instrs)
    assert 0x0800bfe2 + len(hook_bytes) == 0x0800c034

    off_hook = 0x00bfe2
    data[off_hook:off_hook+len(hook_bytes)] = hook_bytes

    # GBA header complement checksum verification
    chk = 0
    for b in data[0xa0:0xbd]:
        chk = (chk - b) & 0xff
    chk = (chk - 0x19) & 0xff
    data[0xbd] = chk

    with open(output_path, "wb") as f:
        f.write(data)

    print(f"Patched successfully to: {output_path}")
    print(f"Output SHA256: {hashlib.sha256(data).hexdigest()}")

if __name__ == "__main__":
    src = sys.argv[1] if len(sys.argv) > 1 else "ezkernel_stock.bin"
    dst = sys.argv[2] if len(sys.argv) > 2 else "ezkernel.bin"
    patch_kernel(src, dst)
